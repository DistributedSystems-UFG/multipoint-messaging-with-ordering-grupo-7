"""
Coordenador de exclusão mútua - algoritmo centralizado (livro-texto,
Seção 5.3.2 "A centralized algorithm").

Importante: este processo NÃO é um servidor privilegiado de propósito
especial. É um programa do mesmo tipo dos clientes (poderia rodar em
QUALQUER uma das instâncias de cliente); apenas um deles foi designado
para também desempenhar o papel de coordenador da região crítica. Para
deixar isso evidente no experimento, o mesmo binário/lógica de cliente
roda em todas as instâncias; apenas uma delas é iniciada com este módulo
adicional ativo.

Algoritmo:
  - Um único cliente pode estar dentro da região crítica (acessando o
    score service: GetScore -> calcular -> UpdateScore) por vez.
  - Para entrar, o cliente chama RequestCS. Se ninguém está na região
    crítica, o coordenador concede a permissão imediatamente. Caso
    contrário, o pedido é enfileirado (ordem FIFO de chegada) e a
    chamada RPC fica bloqueada -- nenhuma mensagem é devolvida ao
    cliente até que seja a vez dele, exatamente como no algoritmo do
    livro, em que o coordenador "atrasa" a resposta GRANT até liberar a
    região crítica.
  - Ao sair da região crítica, o cliente chama ReleaseCS. O coordenador
    libera o pedido na cabeça da fila (se houver), concedendo a
    permissão a ele.

Uso:
    python3 coordinator.py [--port 50052]
"""
import argparse
import collections
import logging
import threading
import time
from concurrent import futures

import grpc

import mutex_pb2
import mutex_pb2_grpc


def now_ms() -> int:
    return int(time.time() * 1000)


class MutexServicer(mutex_pb2_grpc.MutexServiceServicer):
    def __init__(self):
        self._lock = threading.Lock()
        self._busy = False
        self._holder = None
        self._queue = collections.deque()  # itens: (client_id, threading.Event)
        self._granted_count = 0

    def RequestCS(self, request, context):
        cid = request.client_id
        event = threading.Event()
        queue_pos = None

        with self._lock:
            if not self._busy:
                self._busy = True
                self._holder = cid
                self._granted_count += 1
                logging.info("GRANT imediato -> %s (fila=0)", cid)
                return mutex_pb2.CSGrant(
                    client_id=cid, server_ts_ms=now_ms(), queue_wait_count=0
                )
            else:
                self._queue.append((cid, event))
                queue_pos = len(self._queue)
                logging.info(
                    "REQUEST %s enfileirado (posicao=%d, segurando=%s)",
                    cid, queue_pos, self._holder,
                )

        # bloqueia aqui -- nenhuma resposta é enviada ao cliente até
        # que o coordenador sinalize o evento (em ReleaseCS)
        event.wait()

        with self._lock:
            self._granted_count += 1
            logging.info("GRANT (apos fila) -> %s", cid)
        return mutex_pb2.CSGrant(
            client_id=cid, server_ts_ms=now_ms(), queue_wait_count=queue_pos - 1
        )

    def ReleaseCS(self, request, context):
        cid = request.client_id
        with self._lock:
            if self._holder != cid:
                logging.warning(
                    "RELEASE de %s ignorado: titular atual é %s", cid, self._holder
                )
                return mutex_pb2.CSAck(ok=False)

            if self._queue:
                next_id, next_event = self._queue.popleft()
                self._holder = next_id
                logging.info(
                    "RELEASE de %s -> repassando para %s (fila restante=%d)",
                    cid, next_id, len(self._queue),
                )
                next_event.set()
            else:
                logging.info("RELEASE de %s -> regiao critica livre", cid)
                self._busy = False
                self._holder = None
        return mutex_pb2.CSAck(ok=True)


def serve(port: int):
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s.%(msecs)03d [COORDINATOR] %(message)s",
        datefmt="%H:%M:%S",
        handlers=[logging.FileHandler("logs/coordinator.log"), logging.StreamHandler()],
    )
    servicer = MutexServicer()
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=128))
    mutex_pb2_grpc.add_MutexServiceServicer_to_server(servicer, server)
    server.add_insecure_port(f"[::]:{port}")
    server.start()
    logging.info("Coordenador de exclusao mutua ouvindo na porta %d", port)
    try:
        server.wait_for_termination()
    except KeyboardInterrupt:
        logging.info("Encerrando. Total de concessoes: %d", servicer._granted_count)
        server.stop(0)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=50052)
    args = parser.parse_args()
    serve(args.port)
