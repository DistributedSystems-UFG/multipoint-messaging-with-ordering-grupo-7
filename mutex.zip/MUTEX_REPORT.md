# Relatório — Exclusão mútua no acesso ao Score Service

## 1. O problema (revisitado da tarefa anterior)

O protocolo exigido pelo enunciado — `GetScore` → calcular → `UpdateScore`
— são duas chamadas RPC independentes. Nada impede que, entre essas duas
chamadas de um cliente, outro cliente complete sua própria sequência. Medido
na tarefa anterior: **46,0%** das atualizações perdidas com 6 clientes
concorrentes, e **59,7%** com 12 clientes (regra "só atualiza para maior"
do servidor barra exatamente os cálculos que chegam atrasados — não evita a
corrida, só decide quem perde dela). Isso é o problema clássico de
**exclusão mútua**: a sequência GetScore→calcular→UpdateScore precisa ser
tratada como uma região crítica, executada por no máximo um cliente de
cada vez.

## 2. Solução proposta: algoritmo centralizado (livro-texto, Seção 5.3.2)

Um processo é designado **coordenador**. Antes de entrar na região crítica
(a sequência GetScore→calcular→UpdateScore), todo cliente pede permissão
ao coordenador; só prossegue quando ela é concedida; ao sair, libera a
permissão explicitamente. Importante: **o coordenador não é um serviço
especial** — é um processo do mesmo tipo dos clientes (`coordinator.py`
reaproveita a mesma estrutura de `client.py`/`server.py`), apenas
designado para também oferecer o `MutexService`. Qualquer instância de
cliente poderia assumir esse papel.

Protocolo implementado (`mutex.proto` + `coordinator.py`):

- **`RequestCS(client_id)`** — se a região crítica está livre, o
  coordenador concede a permissão imediatamente (resposta gRPC
  retorna na hora). Caso contrário, o pedido é colocado em uma fila
  **FIFO** e a chamada gRPC fica bloqueada no servidor — nenhuma
  resposta é enviada até que seja a vez do cliente (equivalente a
  "atrasar a mensagem GRANT" do algoritmo do livro).
- **`ReleaseCS(client_id)`** — o coordenador verifica se há alguém na
  fila; se houver, libera o próximo (ordem de chegada) acordando a
  chamada `RequestCS` bloqueada dele; senão marca a região como livre.

Internamente: `threading.Lock` + `collections.deque` de
`(client_id, threading.Event)`; cada chamada `RequestCS` bloqueada
aguarda em seu próprio `Event`, sinalizado pelo `ReleaseCS` de quem
estava segurando a região crítica.

O cliente (`client_mutex.py`) envolve a sequência original com o
protocolo:

```
grant = mutex_stub.RequestCS(...)        # bloqueia até ser concedido
score = score_stub.GetScore(...)
novo  = score + pontos
score_stub.UpdateScore(novo, ...)
mutex_stub.ReleaseCS(...)
```

## 3. Testes executados

Mesma carga de trabalho da tarefa anterior (para comparação direta),
agora com o protocolo de exclusão mútua ativo: servidor de score e
coordenador como processos separados; N clientes concorrentes, cada um
fazendo 25 rodadas.

| Execução | Clientes | Tentativas | Sucesso | Rejeitado | Sobreposição de região crítica |
|---|---|---|---|---|---|
| run4 | 6 | 150 | **100,0%** | 0 | **0** |
| run5 | 12 | 300 | **100,0%** | 0 | **0** |

Comparação direta com a tarefa anterior (mesmos parâmetros de
contenção):

| | Sem exclusão mútua | Com exclusão mútua |
|---|---|---|
| 6 clientes | 46,0% rejeitado | **0% rejeitado** |
| 12 clientes | 59,7% rejeitado | **0% rejeitado** |

**Prova de exclusão mútua.** Cada round do cliente registra o instante de
entrada e saída da região crítica (`cs_enter_epoch_ms`/`cs_exit_epoch_ms`
nos CSVs). Verificamos, para as 150 e 300 entradas de cada execução, se
existe qualquer par de intervalos `[entrada, saída]` de clientes
diferentes que se sobreponha no tempo — **zero sobreposições em ambas as
execuções**. Esse é o teste decisivo: não basta a taxa de sucesso ser
100%, é preciso que dois clientes nunca estejam simultaneamente dentro do
trecho GetScore→UpdateScore. O log do `score_service` (`server.log`)
corrobora isso de forma independente: todo par `GET`/`UPDATE` consecutivo
pertence sempre ao mesmo `client_id`, nunca há intercalação.

## 4. Trade-off observado: custo da serialização

| Cenário | Espera média p/ permissão | Espera máxima | Maior fila observada |
|---|---|---|---|
| 6 clientes | 173,7 ms | — | 4 |
| 12 clientes | 422,2 ms | 640,2 ms | 10 |

Dobrar o número de clientes mais que dobrou o tempo médio de espera pela
permissão. Isso é exatamente o trade-off esperado do algoritmo
centralizado discutido no livro-texto (Cap. 5): ele é simples, correto e
garante exclusão mútua e justiça (FIFO), mas o coordenador único é um
**gargalo** — todo pedido de toda a malha de clientes passa por ele, e
ele é também um **ponto único de falha** (se o coordenador cair, nenhum
cliente consegue mais entrar na região crítica). A vantagem de eliminar
100% dos lost updates tem como custo direto a latência adicional de
espera na fila e a perda de paralelismo entre os clientes — que antes
podiam fazer leituras/escritas concorrentemente (gerando corrida), agora
são inteiramente serializados.

## 5. Vídeo de demonstração

`video_assets/demo_mutex.mp4` (1280×720, ~77s) — reconstrução em vídeo a
partir dos **logs reais** desta execução (`run4_6clientes_com_mutex`),
mostrando: o problema identificado, a arquitetura do experimento, o
protocolo, um trecho ao vivo do log combinado coordenador+score-service
(REQUEST/GRANT/RELEASE intercalado com GET/UPDATE), e os resultados
consolidados antes/depois. `video_assets/full_transcript.txt` traz a
transcrição completa e cronológica de toda a execução (748 eventos), caso
seja necessário auditar qualquer trecho além do que aparece no vídeo.
`video_assets/make_demo_video.py` é o script que gera o vídeo a partir
dos logs — reprodutível com qualquer outra execução.

## 6. Limitações e próximos passos

O algoritmo centralizado resolve corretamente o problema, mas herda as
limitações conhecidas de qualquer coordenação centralizada: gargalo de
throughput, latência adicional por round-trip extra, e SPOF (mitigável
com eleição de um novo coordenador via algoritmo bully/anel, já coberto
no mesmo capítulo do livro, caso o coordenador falhe). Para cenários com
muito mais clientes ou clientes geograficamente dispersos, valeria avaliar
um algoritmo distribuído (ex. Ricart-Agrawala) ou eliminar a necessidade
de exclusão mútua no nível da aplicação, adotando uma operação atômica de
incremento no próprio score service (discutido na tarefa anterior).
