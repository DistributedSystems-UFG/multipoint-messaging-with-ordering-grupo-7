#!/bin/bash
# Sobe o score service + coordenador de exclusao mutua, e dispara N clientes
# concorrentes que usam o protocolo RequestCS/ReleaseCS.
# Uso: ./run_local_test_mutex.sh <n_clientes> <rounds> <think_time> <pace>
set -e
cd "$(dirname "$0")"

N=${1:-6}
ROUNDS=${2:-25}
THINK=${3:-0.08}
PACE=${4:-0.1}

rm -f logs/*.log logs/*.csv

python3 server.py --port 50051 > logs/server_stdout.log 2>&1 &
SERVER_PID=$!
python3 coordinator.py --port 50052 > logs/coordinator_stdout.log 2>&1 &
COORD_PID=$!
echo "Servidor (PID=$SERVER_PID) e coordenador (PID=$COORD_PID) iniciados"
sleep 1.5

CLIENT_PIDS=()
for i in $(seq 1 "$N"); do
  python3 client_mutex.py --server localhost:50051 --coordinator localhost:50052 \
    --client-id "p$i" --rounds "$ROUNDS" \
    --min-points 1 --max-points 15 --think-time "$THINK" --pace "$PACE" &
  CLIENT_PIDS+=($!)
done

for pid in "${CLIENT_PIDS[@]}"; do
  wait "$pid"
done

echo "---- todos os clientes terminaram ----"
sleep 0.5
kill "$SERVER_PID" "$COORD_PID" 2>/dev/null || true
sleep 0.5
echo "---- servidor e coordenador encerrados ----"
