# Score Service — manutenção do escore de um jogo multi-player

Implementação em **Python + gRPC** (Protocol Buffers como IDL). Um único
processo de servidor mantém o escore global em memória; múltiplos clientes
(jogadores) consultam e tentam atualizar esse escore concorrentemente.

## Regras implementadas

1. Para atualizar o escore, o cliente sempre: `GetScore()` → calcula o novo
   valor → `UpdateScore(novo_valor)`. Os três passos NÃO são atômicos entre
   si (são duas chamadas RPC distintas), de propósito — é isso que o
   experimento explora.
2. No servidor, `UpdateScore` só aplica a mudança se
   `novo_valor > escore_atual`; a verificação e a escrita são feitas sob o
   mesmo lock (`threading.Lock`), portanto são atômicas **do lado do
   servidor**. Se outro cliente atualizou o escore entre o `GetScore` e o
   `UpdateScore` deste cliente, e o valor dele já não é mais maior que o
   atual, o pedido é **rejeitado** (não há "merge"; é tudo-ou-nada).

## Arquivos

```
score.proto          # definição do serviço (IDL)
score_pb2.py          # stub gerado (mensagens)
score_pb2_grpc.py      # stub gerado (serviço)
server.py             # servidor — roda na instância "service"
client.py             # cliente — roda em cada instância "jogador"
run_local_test.sh     # orquestra um teste local com N clientes (debug/CI)
requirements.txt
```

## 1. Preparar o ambiente (em CADA instância EC2: servidor e clientes)

```bash
sudo apt update && sudo apt install -y python3-pip
pip3 install -r requirements.txt --break-system-packages
```

Os arquivos `score_pb2.py` e `score_pb2_grpc.py` já vão prontos (gerados a
partir do `.proto`); não é preciso regenerar. Caso queira regenerar:

```bash
python3 -m grpc_tools.protoc -I proto --python_out=. --grpc_python_out=. proto/score.proto
```

## 2. Topologia recomendada na AWS

- **1 instância EC2** = servidor do score service (ex.: `t3.micro`,
  Ubuntu 22.04).
- **N instâncias EC2** = uma por jogador/cliente concorrente (podem ser
  `t3.micro` também; o cliente é leve).
- No **Security Group da instância do servidor**, liberar a porta TCP
  `50051` apenas para o(s) Security Group(s)/CIDR das instâncias de
  cliente (inbound rule, não é preciso expor à internet).

## 3. Subir o servidor (instância "service")

```bash
mkdir -p logs
python3 server.py --port 50051
```

Anote o **IP privado** dessa instância (ex. `10.0.1.23`) — é ele que os
clientes vão usar (mais barato e mais rápido que IP público, já que estão
na mesma VPC).

## 4. Rodar um cliente em cada instância "jogador"

```bash
mkdir -p logs
python3 client.py \
  --server 10.0.1.23:50051 \
  --client-id ec2-jogador-A \
  --rounds 50 \
  --min-points 1 --max-points 15 \
  --think-time 0.08 \
  --pace 0.1
```

Parâmetros:

- `--think-time`: atraso (s) entre o `GetScore` e o `UpdateScore` — simula
  o tempo do jogador "fazendo pontos". Quanto maior, maior a janela de
  corrida.
- `--pace`: atraso (s) entre rodadas — controla a frequência de jogadas.
- Cada cliente grava um CSV em `logs/client_<id>.csv` com toda tentativa
  (sucesso ou rejeitada).

Repita o comando acima em cada instância de cliente, simultaneamente (pode
disparar todas via `ssh` em paralelo, ou usar AWS Systems Manager Run
Command para os N hosts de uma vez).

## 5. Coletar e consolidar os resultados

Depois que todos os clientes terminarem, copie os CSVs de cada instância
(`scp`) para uma máquina central e agregue. Métricas relevantes:

- número total de `UpdateScore` tentados vs. aceitos vs. rejeitados;
- escore final do servidor (`logs/server.log` na instância do serviço);
- exemplos de tentativas rejeitadas — comparar `attempted_new_score` da
  tentativa rejeitada com o `score_after_on_server` registrado para
  confirmar que perdeu para um update concorrente mais rápido.

## 6. Teste local rápido (sem AWS, útil para depurar antes do deploy)

```bash
./run_local_test.sh 6 25 0.08 0.1   # 6 clientes, 25 rodadas cada, alta contenção
```

## 7. Exclusão mútua (tarefa seguinte)

Arquivos adicionais: `mutex.proto`, `coordinator.py`, `client_mutex.py`,
`run_local_test_mutex.sh`. Implementam o algoritmo de exclusão mútua com
coordenador centralizado (livro-texto, Seção 5.3.2) para serializar o
acesso de todos os clientes à sequência GetScore→calcular→UpdateScore.
Detalhes, protocolo e resultados em `MUTEX_REPORT.md`.

Topologia na AWS: além das instâncias de servidor e clientes já descritas,
**uma instância adicional** (ou qualquer uma das de cliente) roda
`coordinator.py`:

```bash
# na instância do coordenador
mkdir -p logs
python3 coordinator.py --port 50052
```

```bash
# em cada instância de cliente
mkdir -p logs
python3 client_mutex.py \
  --server <ip_score_service>:50051 \
  --coordinator <ip_coordenador>:50052 \
  --client-id ec2-jogador-A \
  --rounds 50 --think-time 0.08 --pace 0.1
```

Liberar a porta `50052` no Security Group do coordenador, da mesma forma
que a porta `50051` do score service.

Teste local rápido:

```bash
./run_local_test_mutex.sh 6 25 0.08 0.1
```

