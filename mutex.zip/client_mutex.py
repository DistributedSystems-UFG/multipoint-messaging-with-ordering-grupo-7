"""
Cliente do Score Service COM exclusão mútua via coordenador centralizado.

Diferença em relação a client.py (tarefa anterior): antes de executar a
sequência GetScore -> calcular -> UpdateScore, o cliente pede permissão ao
coordenador (RequestCS) e só entra na região crítica quando ela é
concedida; ao terminar a sequência, libera (ReleaseCS). Isso serializa o
acesso de todos os clientes ao score service, eliminando a condição de
corrida (lost update) observada na tarefa anterior.

Uso:
    python3 client_mutex.py --server HOST:PORT --coordinator HOST:PORT \
        --client-id p1 --rounds 20 --think-time 0.08 --pace 0.1
"""
import argparse
import csv
import random
import time

import grpc

import score_pb2
import score_pb2_grpc
import mutex_pb2
import mutex_pb2_grpc


def run_client(server_addr, coord_addr, client_id, rounds, min_points,
                max_points, think_time, pace, out_dir):
    score_channel = grpc.insecure_channel(server_addr)
    score_stub = score_pb2_grpc.ScoreServiceStub(score_channel)
    mutex_channel = grpc.insecure_channel(coord_addr)
    mutex_stub = mutex_pb2_grpc.MutexServiceStub(mutex_channel)

    rows = []
    for i in range(rounds):
        t_req0 = time.time()

        # --- pede a regiao critica ao coordenador (bloqueia ate ser concedida)
        grant = mutex_stub.RequestCS(mutex_pb2.CSRequest(client_id=client_id))
        t_cs_start = time.time()
        wait_for_grant_ms = round((t_cs_start - t_req0) * 1000, 2)

        # ======== INICIO DA REGIAO CRITICA ========
        read_reply = score_stub.GetScore(score_pb2.Empty())
        base_score = read_reply.score

        if think_time > 0:
            time.sleep(random.uniform(0, think_time))

        points = random.randint(min_points, max_points)
        new_score = base_score + points

        upd_reply = score_stub.UpdateScore(score_pb2.UpdateRequest(
            new_score=new_score, client_id=client_id, base_score=base_score
        ))
        # ======== FIM DA REGIAO CRITICA ========
        t_cs_end = time.time()

        mutex_stub.ReleaseCS(mutex_pb2.CSRelease(client_id=client_id))

        rows.append({
            "client_id": client_id,
            "round": i,
            "wait_for_grant_ms": wait_for_grant_ms,
            "queue_wait_count": grant.queue_wait_count,
            "cs_duration_ms": round((t_cs_end - t_cs_start) * 1000, 2),
            "base_score_read": base_score,
            "points": points,
            "attempted_new_score": new_score,
            "success": upd_reply.success,
            "score_after_on_server": upd_reply.current_score,
            "cs_enter_epoch_ms": int(t_cs_start * 1000),
            "cs_exit_epoch_ms": int(t_cs_end * 1000),
        })

        if pace > 0:
            time.sleep(random.uniform(0, pace))

    out_path = f"{out_dir}/client_{client_id}.csv"
    with open(out_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    successes = sum(1 for r in rows if r["success"])
    print(f"[{client_id}] rounds={rounds} sucessos={successes} "
          f"rejeitados={rounds - successes} -> log: {out_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--server", required=True, help="host:porta do score service")
    parser.add_argument("--coordinator", required=True, help="host:porta do coordenador de exclusao mutua")
    parser.add_argument("--client-id", required=True)
    parser.add_argument("--rounds", type=int, default=20)
    parser.add_argument("--min-points", type=int, default=1)
    parser.add_argument("--max-points", type=int, default=10)
    parser.add_argument("--think-time", type=float, default=0.05)
    parser.add_argument("--pace", type=float, default=0.2)
    parser.add_argument("--out-dir", default="logs")
    args = parser.parse_args()

    run_client(args.server, args.coordinator, args.client_id, args.rounds,
               args.min_points, args.max_points, args.think_time, args.pace,
               args.out_dir)
